from textblob import TextBlob
blob = TextBlob("")
t = []
for sentence in blob.sentences:
     t.append(sentence.sentiment.polarity)
print(sum(t)/len(t))