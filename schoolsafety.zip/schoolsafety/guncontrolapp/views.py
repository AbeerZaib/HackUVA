import math
from django.shortcuts import render
from django.template import RequestContext
from django.shortcuts import render
# Create your views here.
from django.template import loader
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect
from django.http import Http404
import json
from datetime import datetime
import requests
from collections import Counter
from string import punctuation
import re
import random

from google.cloud import language
from google.cloud.language import enums
from google.cloud.language import types

from nbconvert.filters import html2text
from twitter import Twitter, OAuth, TwitterHTTPError
# -*- coding: utf-8 -*-
import sys

OAUTH_TOKEN = '807256666437779461-947bWZ0GW15PsjcbSiZDt5l9WTH6EXY'
OAUTH_SECRET = 'HbP6sAlvHJ73rBvviqYZc42W0qFwr3kXwV3FSI0Q0LyHj'
CONSUMER_KEY = 'MvzSssZISIk7de8XRehlP2wdj'
CONSUMER_SECRET = 'YIivV6tol7MxuD61ECUG5I5IbVTrwDq4dff331cvC95Tow47UH'
t = Twitter(auth=OAuth(OAUTH_TOKEN, OAUTH_SECRET, CONSUMER_KEY, CONSUMER_SECRET))
og = 'us-east1.17779236732691073588'
url = "https://videointelligence.googleapis.com/v1/operations/" + og
headers = {
        'authorization': "Bearer ya29.GqQBiQUnoJMDMrNBneqwmzlXX1TXcaAMHRcAKJGMPNe3wm3MgyMlZmRRqDnWpcUNrxCgs6ig5EK6o8gRedWNUGKMjmSb2ASQ5-3dqW_jPNOvgaqLEnVLRt9ECdqYictM93AGPnbIfxcod5F3rdHQ9slX7gk1O7TjRw8ZvFKLfEHJzXiREZKNTWB4uQg75oGO8CVvYMxj2nalBBJSxj_lpFArYa7G1Dw",
        'content-type': "application/json",
        'cache-control': "no-cache",
        'postman-token': "22f3c7ec-9586-1bd0-18a9-7ceeb5444a70"
    }
#response = requests.request("GET", url, headers=headers)

def sentiment(text):
    from textblob import TextBlob
    #client = language.LanguageServiceClient()
    #document = types.Document(
    #    content=text,
    #    type=enums.Document.Type.PLAIN_TEXT)
    # Detects the sentiment of the text
    #sentiment = client.analyze_sentiment(document=document).document_sentiment
    blob = TextBlob(str(text))
    t = []
    for sentence in blob.sentences:
        t.append(sentence.sentiment.polarity)
        #t.append(sentiment.score* sentiment.magnitude)
    if len(t) == 0:
        return 0
    return sum(t) / len(t)


def search_tweets(q, count=100, max_id=None):
    return t.search.tweets(q=q, count=count, lang="en", max_id=max_id)

def return_tweetset():
    x = dict(dict(search_tweets(r"q=guns%2C%20OR%20violence", 250)))
    complete = []
    for k, v in x.items():
        print(k, v)
        for n in v:
            a=''
            if not isinstance(n, str) and 'text' in n.keys():
                if ':' in n['text'] and len(n['text'])>1:
                    a = (n['text']).split(':', 1)
            if a != '' and a[0] != '' and a[1] != '' and len(a[1])>len(a[0]) and a[0]!="RT @KimKardashian":
                complete.append((a[0],a[1],sentiment(''.join(a))))
            print(complete)
    return complete
# Create your views here.
def index(request):
    return render(request, 'index.html')

def socialmedia(request):
    print(return_tweetset())
    return render(request, 'socialmedia.html',{"contextList":return_tweetset()})

def videoanalyzer(request):
    n = (json.loads(open('templates/chicago.json').read()))["response"]["annotationResults"][0]["segmentLabelAnnotations"]
    vals = []
    for d in n:
        desc = ""
        if 'categoryEntities' in d.keys():
            desc = d['categoryEntities'][0]['description']
        else:
            desc = d['entity']['description']
        con = d['segments'][0]['confidence']
        vals.append((desc, con))
    weighted = []
    for d,c in vals:
        if c >.8:
            weighted.append(sentiment(d)*c)
    aa = 0
    if len(weighted) != 0:
        aa = round(sum(weighted)/len(weighted) *100, 2)
    return render(request, 'videoanalyzer.html',{"tuples":vals,"roa":aa})
def mainmenu(request):
    url = "https://api-sandbox.safetrek.io/v1/alarms"

    payload = "{\r\n  \"services\": {\r\n    \"police\": true,\r\n    \"fire\": false,\r\n    \"medical\": false\r\n  },\r\n  \"location.coordinates\": {\r\n    \"lat\": 34.32334,\r\n    \"lng\": -117.3343,\r\n    \"accuracy\": 5\r\n  }\r\n}"
    headers = {
        'authorization': "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Ik5FWTBPVVV3TVRSRU5qUTRSVUZDTkVJd01rUTBSVEUwUVRJMFF6ZzRSVGc1T0RBMFJEWXhOUSJ9.eyJodHRwOi8vY2xpZW50LW5hbWUiOiJIQUNLX1VWQSIsImlzcyI6Imh0dHBzOi8vbG9naW4tc2FuZGJveC5zYWZldHJlay5pby8iLCJzdWIiOiJzbXN8NWFiNjk5ZjVhNjgwM2E5MTkxMWU0ODM2IiwiYXVkIjpbImh0dHBzOi8vYXBpLXNhbmRib3guc2FmZXRyZWsuaW8iLCJodHRwczovL3NhZmV0cmVrLXNhbmRib3guYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTUyMTk3OTMxMywiZXhwIjoxNTIyMDE1MzEzLCJhenAiOiJtNXFYRjV6dE9kVDRjZFF0VWJaVDJnckJoRjE4N3Z3NiIsInNjb3BlIjoib3BlbmlkIHBob25lIG9mZmxpbmVfYWNjZXNzIn0.6DzhtNaA9nf1LOuanZPDNInoQ35AZS7NGQD02jeUEurB2C47tHnpQIqyW3oLys_5ljCG3TW90FKSsq_yM9eJal1R-cjEK5GPBREuNB3GZDhWBKh9keJAexZG3ExOQYQeOP6fEjmtRGA67FijS8yXDckyF1S7vya2KQS92w-jlpiKEMrEE_pSAuBz7Ev482_hYU_5ttoIOnQcd-2TiybaUckRtq2KIF7PMQCSrLeb_hR62vgvxuY_81ttZRf_SQI3AEDiFP4NWbrBXDA4kW_EMzPjSHk6wXneFstxEW7vvQ8tWWyE3QZLoRNP0kpbEfzgdAdX6fnONDgmKiEXdz8WxQ",
        'content-type': "application/json",
        'cache-control': "no-cache",
        'postman-token': "f7069d08-8338-b886-bfaf-8a201e5bc727"
    }

    response = requests.request("POST", url, data=payload, headers=headers)
    return render(request, 'mainmenu.html', {})

