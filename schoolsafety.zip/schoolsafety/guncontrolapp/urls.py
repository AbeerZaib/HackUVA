from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('mainmenu', views.mainmenu, name='mainmenu'),
    path('socialmedia', views.socialmedia, name='socialmedia'),
    path('videoanalyzer', views.videoanalyzer, name='videoanalyzer'),
]