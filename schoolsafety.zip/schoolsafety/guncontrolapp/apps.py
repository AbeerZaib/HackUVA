from django.apps import AppConfig


class GuncontrolappConfig(AppConfig):
    name = 'guncontrolapp'
