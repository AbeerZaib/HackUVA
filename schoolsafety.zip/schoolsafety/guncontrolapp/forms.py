from django import forms

class Submit(forms.Form):
    url = forms.URLField()