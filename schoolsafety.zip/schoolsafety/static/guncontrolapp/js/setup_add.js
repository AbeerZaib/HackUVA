function recreate(){
	
	document.getElementById("mainheader").innerHTML = "Step 3- Add your content"
}